package com.saithy;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


import static com.saithy.Numbers.Compute;



class Calculator {


    public static void main(String[] args) throws IOException {

        String value;   // Получение выражения,
                        // exit для выхода
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        boolean exit = true;
        while (exit) {
            value = reader.readLine(); // Ввод операции с клавиатуры
            if (value.equals("exit")) { exit = false; break; } // Проверка условия выхода
            char[] strToArray = value.toCharArray(); // Преобразуем строку str в массив символов (char)

            Compute(strToArray);

        }


    }

}