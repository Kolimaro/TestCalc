package com.saithy;


import static com.saithy.Calculation.*;

public class Numbers {

    public static void Compute(char[] array) {
        String newStr = "";
        String firstNumber = "", secondNumber = "";
        int ArabNumber1, ArabNumber2;

        for (char x : array) {
            if (x != ' ') {                  //Убираем лишние пробелы из выражения
                newStr += x;
            }
        }


        char[] newArr = newStr.toCharArray();


        int k = 0;
        while (newArr[k] != '+' && newArr[k] != '-' && newArr[k] != '*' && newArr[k] != '/') {

            firstNumber += newArr[k];               //Получение первого операнда
            k++;
        }
        char oper = newArr[k];                           //Получение оператора
        k++;

        while (k < newArr.length) {
            secondNumber += newArr[k];              //Получение второго операнда
            k++;
        }


                                                    //Проверка арабские или римские цифры
            if (firstNumber.equals("0") || firstNumber.equals("1") || firstNumber.equals("2") || firstNumber.equals("3") || firstNumber.equals("4") || firstNumber.equals("5")
               || firstNumber.equals("6") || firstNumber.equals("7") || firstNumber.equals("8") || firstNumber.equals("9") || firstNumber.equals("10")) {

                if (secondNumber.equals("0") || secondNumber.equals("1") || secondNumber.equals("2") || secondNumber.equals("3") || secondNumber.equals("4") || secondNumber.equals("5")
                   || secondNumber.equals("6") || secondNumber.equals("7") || secondNumber.equals("8") || secondNumber.equals("9") || secondNumber.equals("10")) {

                    if ((Integer.parseInt(firstNumber) <= 0 && Integer.parseInt(firstNumber) >= 10) && (Integer.parseInt(secondNumber) <= 0 && Integer.parseInt(secondNumber) >= 10)) {
                        throw new NumberFormatException("Допустимый интервал от 1 до 10.");
                    }else System.out.println(resultCalculation(Integer.parseInt(firstNumber), Integer.parseInt(secondNumber), oper));   //Вычисление в арабских числах и вывод результата

                } else throw new NumberFormatException("Только арабские или только римские");

            }else {
                RomanNumeral romanNumber1 = new RomanNumeral(firstNumber);
                ArabNumber1 = (romanNumber1.toInt());                                   //Преобразование римских в арабские
                RomanNumeral romanNumber2 = new RomanNumeral(secondNumber);
                ArabNumber2 = (romanNumber2.toInt());
                int CalculatedRome = resultCalculation(ArabNumber1, ArabNumber2, oper);
                RomanNumeral Roman = new RomanNumeral(CalculatedRome);                  //Преобразование арабских в римские
                System.out.println(Roman.toString());                                   //Вывод ответа на экран

            }

    }

}
