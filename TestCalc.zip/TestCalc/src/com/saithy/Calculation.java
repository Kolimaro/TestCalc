package com.saithy;


import static com.saithy.Operations.*;

public class Calculation {

    public static int resultCalculation(int a, int b, char operation) { //Вычисление результата
        int value = 0;
        switch (operation) {
            case '+':
                value = plus(a, b);;
                break;
            case '-':
                value = minus(a, b);
                break;
            case '*':
                value = multipl(a, b);
                break;
            case '/':
                if (b == 0) {
                    System.out.println("Деление на 0 невозможно!");
                }
                value = div(a, b);
                break;
            default:
                System.out.println("Hе корректная операция");
        }
        return value;

    }

}
